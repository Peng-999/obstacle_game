using UnityEngine;

public class dropper : MonoBehaviour
{
    MeshRenderer Myrenderer;
    Rigidbody Myrigidbody;
    [SerializeField] float timeToWait = 5f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Myrenderer = GetComponent<MeshRenderer>();
        Myrigidbody = GetComponent<Rigidbody>();
        GetComponent<Renderer>().enabled = false;
        GetComponent<Rigidbody>().useGravity = false;

    }

    // Update is called once per frame
    void Update()
    {
        if(Time.time>timeToWait)
        {
            Myrenderer.enabled = true;
            Myrigidbody.useGravity = true;
        }
    }
}
